module.exports = {
  darkMode: 'class', // enables `dark:` variants
  content: [
    './app/**/*.{js,ts,jsx,tsx}',      // App Router
    './pages/**/*.{js,ts,jsx,tsx}',    // Pages Router
    './components/**/*.{js,ts,jsx,tsx}' // Components
  ],
  theme: {
    extend: {
      colors: {
        //bg: 'var(--bg)',
      },
    },
  },
  plugins: [],
}