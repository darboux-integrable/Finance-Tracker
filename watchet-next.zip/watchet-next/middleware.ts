// middleware.ts
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { adminAuth } from "@/app/lib/firebase.admin";

export async function middleware(request: NextRequest) {
  const sessionCookie = request.cookies.get("session")?.value;

  if (sessionCookie) {
    try {
      // verify Firebase session
      await adminAuth.verifySessionCookie(sessionCookie, true);
      return NextResponse.next(); // allow request
    } catch {
      // clear cookie if invalid
      const res = NextResponse.redirect(new URL("/login", request.url));
      res.cookies.set("session", "", { maxAge: 0, path: "/" });
      return res;
    }
  }

  // no session cookie
  if (request.nextUrl.pathname.startsWith("/api/protected")) {
    return new NextResponse("Unauthorized", { status: 401 });
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/api/protected/:path*"], // paths where middleware runs
};