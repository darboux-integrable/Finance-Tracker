![Logo](https://dev-to-uploads.s3.amazonaws.com/uploads/articles/th5xamgrr6se0x5ro4g6.png)



[shields.io](https://shields.io/)
<p align="center">
  <img alt="Language: Typescript" src="https://img.shields.io/badge/TypeScript-3178C6?logo=typescript&logoColor=white" />
  <img alt="Tech: Next.js" src="https://img.shields.io/badge/Next.js-000000?style=for-the-badge&logo=next.js&logoColor=white" />
  <img alt="Tech: React" src="https://img.shields.io/badge/React-61DAFB?style=for-the-badge&logo=react&logoColor=black" />
  <img alt="Version: 1.0.0" src="https://img.shields.io/badge/version-1.0.0-blue" />
  <img alt="License: MIT" src="https://img.shields.io/badge/License-MIT-green" />
</p>

# Watchet
[🔗 Project Website](https://example.com)

Watchet is an all-in-one finance management platform for tracking your finances.


## 🖼️Preview

### Screenshots

<p align="center">
  <img src="https://via.placeholder.com/468x300?text=App+Screenshot+Here" />
  <img src="https://via.placeholder.com/468x300?text=App+Screenshot+Here" />
  <img src="https://via.placeholder.com/468x300?text=App+Screenshot+Here" />
</p>

### Video Demo

[![Watch the video](https://img.youtube.com/vi/VIDEO_ID/0.jpg)](https://www.youtube.com/watch?v=VIDEO_ID)

## 🛠️Tech Stack

**Client:** React, TailwindCSS

**Server:** Next.js, Firebase Admin

### Features:

- Light/dark mode toggle
- Session cookies
- Save settings across devices


## 📥Installation

Download project, run the follow terminal commands:

```bash
  cd watchet-next
  npm install
  npm run dev
```
    
#### Environment Variables

Add the following environment variables to your .env file from `%DATABASE%`

`API_KEY`


## 👥Collaborators

- [@darboux-integrable](https://www.github.com/darboux-integrable)