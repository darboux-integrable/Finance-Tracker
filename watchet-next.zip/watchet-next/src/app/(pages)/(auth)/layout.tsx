"use client";

import { useEffect, useState, ReactNode } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "motion/react";
import toast from "react-hot-toast";
import Link from "next/link";

import Tooltip from "@/app/components/ui/Tooltip";
import UnderlineLink from "@/app/components/ui/UnderlinedLink";
import { checkLogin } from "@/app/lib/client/auth";

export default function AuthLayout({ children }:{ children: React.ReactNode }) {
  const router = useRouter();
  const authAnimDur = 150;

  async function cookieCheck() {
    const res = await checkLogin();
    if (res) {
      toast.success("Logged in!");
      router.push("/dashboard");
    }
  }

  useEffect(() => {
    cookieCheck();
    const handleVisibilityChange = () => {
      if (document.visibilityState === "visible") {
        cookieCheck();
      }
    };
    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }, []);

    return (
        <div className="flex flex-row h-screen w-screen bg-[var(--background)] p-[10px]">
            <div className="grow">
                {/* FOR IMAGE */}
            </div>

            {/* Nav to landing */}
            <Link
                href="/"
                className="absolute top-5 left-5 px-[10px] py-[4px] transition-all duration-200 hover:shadow-none hover:scale-105"
                onClick={() => toast.dismiss()}
            >
                <img src="/brand/titleIcon.svg" alt="Watchet" className="w-[150px]" />
            </Link>

            <main className="relative flex flex-col justify-center items-center bg-[var(--lvl1-container)] rounded-[15px] w-[35vw] py-[50px] px-[5vw]">
                <AnimatePresence mode="wait">
                    <motion.div
                        className="w-full"
                        initial={{ opacity: 0, y: -30, scale: 1.05 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: -30, scale: 1.05 }}
                        transition={{ duration: authAnimDur / 1000, ease: "easeInOut" }}
                    >
                        {children}
                    </motion.div>
                </AnimatePresence>

                {/* Legal links */}
                <div className="absolute bottom-[10px] flex justify-center min-w-[550px] w-[25vw] max-w-[625px] text-[0.8em]">
                    <Link href="/terms" className="text-[var(--secondary-text-color)] hover:text-[var(--secondary-text-hover)] hover:underline">
                        Terms
                    </Link>
                    <span className="mx-[5px] text-[var(--secondary-text-color)]">|</span>
                    <Link href="/privacy" className="text-[var(--secondary-text-color)] hover:text-[var(--secondary-text-hover)] hover:underline">
                        Privacy
                    </Link>
                </div>
            </main>
        </div>
    );
}