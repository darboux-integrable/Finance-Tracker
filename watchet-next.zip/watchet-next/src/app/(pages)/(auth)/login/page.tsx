"use client";

import { useState, KeyboardEvent } from "react";
import toast  from "react-hot-toast";

import TextInput from "@/app/components/ui/TextInput/TextInput";
import UnderlineLink from "@/app/components/ui/UnderlinedLink";
import { login, emailLogin, forgotPassword } from "@/app/lib/client/auth";

type LoginProps = {
  delayedNavigate: (to: string) => void;
};

export default function Login({ delayedNavigate }: LoginProps) {
  const [email, setEmail] = useState({ value: "", alertMsg: "" });
  const [password, setPassword] = useState({ value: "", alertMsg: "" });
  const [rememberMe, setRememberMe] = useState(true);
  const inputs = [
    [email, setEmail],
    [password, setPassword],
  ] as const;

  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  const resetAlerts = () => {
    inputs.forEach(([_, setter]) => setter((prev) => ({ ...prev, alertMsg: "" })));
  };

  const loginUser = () => {
    let returnWithError = false;
    resetAlerts();

    // Email validation
    if (email.value !== "" && !emailRegex.test(email.value)) {
      setEmail((prev) => ({ ...prev, alertMsg: "Email format invalid" }));
      returnWithError = true;
    }

    // Check empty fields
    let emptyExists = false;
    inputs.forEach(([field, setter]) => {
      if (field.value === "") {
        if (!emptyExists) {
          setter((prev) => ({ ...prev, alertMsg: "Fill out all fields" }));
          emptyExists = true;
          returnWithError = true;
        } else {
          setter((prev) => ({ ...prev, alertMsg: "!" }));
        }
      }
    });

    if (returnWithError) return;

    const logInPromise = login(email.value.toLowerCase(), password.value, rememberMe);
    toast.promise(logInPromise, {
      loading: "Logging in...",
      success: () => {
        delayedNavigate("/dashboard");
        return "Log in successful!";
      },
      error: (error: any) => {
        switch (error) {
          case "auth/invalid-email":
          case "auth/wrong-password":
          case "auth/invalid-credential":
            setEmail((prev) => ({ ...prev, alertMsg: "!" }));
            setPassword((prev) => ({ ...prev, alertMsg: "!" }));
            return "Invalid email or password";
          case "Email not verified":
            setEmail((prev) => ({ ...prev, alertMsg: "Email not verified, log in by email" }));
            return "Email not verified";
          case "auth/network-request-failed":
            return "Network related error";
          case "auth/too-many-requests":
            return "Too many requests, try again later";
          case "Recent login required":
            return "Recent login required";
          default:
            return "Error authenticating";
        }
      },
    });
    


  };

  const loginByEmail = () => {
    resetAlerts();
    if (email.value === "") {
      setEmail((prev) => ({ ...prev, alertMsg: "Email is required" }));
      return;
    }
    if (!emailRegex.test(email.value)) {
      setEmail((prev) => ({ ...prev, alertMsg: "Email format invalid" }));
      return;
    }

    const emailLoginPromise = emailLogin(email.value.toLowerCase());
    toast.promise(emailLoginPromise, {
      loading: "Sending email...",
      success: () => {
        delayedNavigate("/emailed");
        return "Email sent to inbox";
      },
      error: (error: string) => {
        switch (error) {
          case "auth/invalid-email":
            setEmail((prev) => ({ ...prev, alertMsg: "!" }));
            return "Invalid email";
          case "auth/network-request-failed":
            return "Network related failure";
          case "auth/too-many-requests":
            return "Too many requests, try again later";
          default:
            return "Error sending email";
        }
      },
    });
  };

  const passwordReset = async () => {
    resetAlerts();
    if (email.value === "") {
      setEmail((prev) => ({ ...prev, alertMsg: "Email is required" }));
      return;
    }
    if (!emailRegex.test(email.value)) {
      setEmail((prev) => ({ ...prev, alertMsg: "Email format invalid" }));
      return;
    }

    const forgotPasswordPromise = forgotPassword(email.value.toLowerCase());
    toast.promise(forgotPasswordPromise, {
      loading: "Sending email...",
      success: () => {
        delayedNavigate("/reset-emailed");
        return "Email sent to inbox";
      },
      error: (error: string) => {
        switch (error) {
          case "auth/invalid-email":
          case "auth/invalid-credential":
            setEmail((prev) => ({ ...prev, alertMsg: "!" }));
            return "Invalid email";
          case "auth/network-request-failed":
            return "Network related failure";
          case "auth/too-many-requests":
            return "Too many requests, try again later";
          default:
            return "Error authenticating";
        }
      },
    });
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === "Enter") loginUser();
  };

  return (
    <>
      <div className="flex flex-col items-center justify-center w-full min-h-screen py-16 space-y-10">
        {/* Icon */}
        <img src="/brand/icon.svg" alt="W" className="w-[120px] h-[120px]" />

        {/* Headings */}
        <div className="space-y-2 text-center">
          <h1 className="text-4xl font-bold text-[var(--primary-text-color)]">Welcome Back!</h1>
          <p className="text-lg text-[var(--secondary-text-color)]">Please enter your details</p>
        </div>

        {/* Inputs */}
        <div className="w-full flex flex-col gap-8 mt-8">
          <div onKeyDown={handleKeyDown}>
            <TextInput
              getter={email}
              setter={setEmail}
              title="EMAIL"
              maxLength={80}
              autoFill="email"
              inpType="text"
              buttonImage="/icons/mail.svg"
              buttonAlt="Send email"
              buttonTooltip="Log in by email"
              buttonAction={loginByEmail}
            />
          </div>
          <div>
            <div onKeyDown={handleKeyDown}>
              <TextInput
                getter={password}
                setter={setPassword}
                title="PASSWORD"
                inpType="password"
                autoFill="current-password"
              />
            </div>
            {/* Forgot password */}
            <div className="flex flex-row mt-1">
              <label className="grow flex items-center gap-2 text-[var(--primary-text-color)] cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 accent-sky-400 cursor-pointer"
                />
                <span className="text-sm">Remember me for 7 days</span>
              </label>
              <UnderlineLink href="#" className=" mt-0 text-sky-500 hover:text-sky-300 text-base">
                Forgot your password?
              </UnderlineLink>
            </div>
          </div>
        </div>

        {/* Login button */}
        <button
          className="w-full h-12 rounded-xl border border-sky-500 text-white text-lg font-semibold bg-sky-500 hover:bg-sky-700 active:bg-sky-800 transition-colors duration-200 mt-6"
          onClick={loginUser}
        >
          Log In
        </button>

        {/* Bottom sign-up link */}
        <div className="flex items-center justify-center gap-1 pt-8">
          <p className="text-[var(--primary-text-color)] text-base">Don't have an Account?</p>
          <UnderlineLink href="/signup" className="text-sky-500 hover:text-sky-300 text-base">
            Sign Up!
          </UnderlineLink>
        </div>
      </div>
    </>
  );
}