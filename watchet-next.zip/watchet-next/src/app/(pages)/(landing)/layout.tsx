import Navbar from "@/app/components/landing/Navbar/Navbar"
import Footer from "@/app/components/landing/Footer/Footer"

export default function LandingLayout({ children }:{ children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar/>
      <div className="pt-[80px] grow">
        {children}
      </div>
      <Footer/>
    </div>
  );
}
