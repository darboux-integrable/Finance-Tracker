"use client";

import styles from "./page.module.css";
import { useState } from "react";

export default function HelpPage() {
  const FAQs = [
    {
      question: "Why Trust Us?",
      answer:
        "We have been programming since middle school. Having multiple years in the field, we can assure you that Wachet is safe and secure for your use!",
    },
    {
      question: "What is Watchet?",
      answer:
        "A finance tracking and management application built to be simple and easily understandable.",
    },
    {
      question: "Why use Watchet?",
      answer:
        "Unlike a big corporation, we're two teenagers who care about our users and Watchet.",
    },
  ];

  return (
    <main className={styles.pageContent}>
      <section className={styles.contact}>
        <img
          src="./images/metorBackground.svg"
          alt=""
          className="relative w-[100vw] max-h-[550px]"
        />
        <div className={styles.contactContainer}>
          <h1 className={styles.contactTitle}>Contact</h1>
          <p className={styles.contactText}>
            Please reach out! If you are having trouble, or experiencing any
            bugs and malfunctions, make us aware! Report any problems by
            emailing
            <strong> AdamevansWork1@gmail.com</strong> or{" "}
            <strong>TylerRobucci@gmail.com</strong> and we will get back as soon
            as possible.
          </p>
        </div>
      </section>
      <section className={styles.legalSection}>
        <div className={styles.TOSContainer}>
          <h2 className={styles.TOSTitle}>Terms of Service</h2>
          <p className={styles.TOSText}>
            Here you can find more information about how the platform works,
            what rules are in place to protect users and creators, along with
            other legal info.
          </p>
        </div>
      </section>
      <section className={styles.FAQContainer}>
        <h1 className={styles.FAQTitle}>FAQs</h1>
        <div className={styles.FAQs}>
          {FAQs.map((FAQ) => {
            const [open, setOpen] = useState(false);
            return (
              <div className={styles.FAQ} key={FAQs.indexOf(FAQ)}>
                <div
                  className={styles.questionContainer}
                  onClick={() => {
                    setOpen(!open);
                  }}
                >
                  <h2 className={styles.FAQTItle}>{FAQ.question}</h2>
                  <img
                    src="./icons/caret.svg"
                    className="w-[40px]"
                    style={{
                      transform: !open ? "rotateZ(90deg)" : "rotateZ(-90deg)",
                    }}
                    alt=""
                  />
                </div>
                <div
                  className={styles.answerContainer}
                  style={{ display: open ? "block" : "none" }}
                >
                  <p className={styles.answerText}>{FAQ.answer}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </main>
  );
}
