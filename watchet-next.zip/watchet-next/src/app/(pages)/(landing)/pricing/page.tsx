'use client';

import Link from 'next/link';
import { useState } from "react";
import { motion } from "motion/react"

import styles from "./page.module.css";

export default function PricingPage() {
  const [isMonthly, setMonthly] = useState(true);

  // Access = 3 means its in all plans
  // Access = 2 means its in only paid plans (trader and pro plans)
  // Access = 1 means its only in the pro plan
  const featuresList = [
    {
      name: "Track Incomes and Expenses",
      access: 3,
    },
    {
      name: "Budgeting Tools",
      access: 3,
    },
    {
      name: "Graphical Visualizations",
      access: 3,
    },
    {
      name: "Debt Tracking",
      access: 2,
    },
    {
      name: "Subscription Management",
      access: 2,
    },
    {
      name: "Connect to Crypto",
      access: 1,
    },
    {
      name: "Stock Tracking",
      access: 1,
    },
    {
      name: "Retirement Planning and Tracking",
      access: 1,
    },
    {
      name: "Tax Filing Help",
      access: 1,
    },
    {
      name: "Personal Finance Lessons",
      access: 1,
    },
    {
      name: "Bank Account Linking",
      access: 1,
    },
  ];

  const addFeaturesList = (accessLevel: any) => {
    let items: any = [];
    featuresList.map((feature) => {
      if (feature.access == accessLevel) {
        items.push(
          <span className={styles.feature} key={feature.name}>
            <img
              className={styles.checkMark}
              src="/icons/checkmark.svg"
              alt="Check Mark"
            />
            <p className={styles.featureText}>{feature.name}</p>
          </span>
        );
      }
    });
    return items;
  };

  return (
    <>
    
      {/* <div className="absolute top-0 left-0 w-full pointer-events-none">
        <img src="/images/3shadeBg.svg" alt="" className="w-[100%] h-[630px] object-cover" />
        <div className="aboslute h-[30px] w-full bg-white"/>
      </div> */}

      <div className={`${styles.blobBackground}`}>
        <h1 className="text-[80px] text-[var(--primary-text-color)] z-5 text-center">Subscription Plans</h1>
      </div>

      <main className={styles.pricingCardsOuterContainer}>

            {/* Toggle */}
            <div className={styles.pricingToggleContainer}>
              <div className={styles.pricingToggleWrapper}>
                <input
                  className={styles.monthlyRadio}
                  id="monthly"
                  type="radio"
                  name="toggle"
                  checked={isMonthly}
                  onChange={() => setMonthly(true)}
                />
                <label
                  className={`${styles.radioLabel} ${styles.monthlyLabel}`}
                  htmlFor="monthly"
                >
                  Monthly
                </label>

                <input
                  className={styles.yearlyRadio}
                  id="yearly"
                  type="radio"
                  name="toggle"
                  checked={!isMonthly}
                  onChange={() => setMonthly(false)}
                />
                <label
                  className={`${styles.radioLabel} ${styles.yearlyLabel}`}
                  htmlFor="yearly"
                >
                  Yearly
                </label>

                <div className={styles.toggleLabelBackground}></div>
              </div>
            </div>

            {/* Cards */}
            <div className="flex-row justify-items-center">
              <section className={styles.pricingCardsContainer}>
              <section className={styles.pricingCard}>
                <div className={styles.pricingContent}>
                  <h2
                    className={`${styles.pricingTitle} text-gray-500`}
                  >
                    Basic
                  </h2>
                  <div className={styles.priceContainer}>
                    <div className={`${styles.numberContainer} overflow-hidden h-[40px] relative`}>
                      <h2 className={styles.wholeNumber}>Free</h2>
                    </div>
                  </div>
                  <Link href="/auth/signup" className={`${styles.buyButton} bg-white hover:bg-sky-600 text-sky-600 hover:text-white`}>Sign Up</Link>
                  <div className={styles.featureListTitle}></div>
                  <div className={styles.featuresList}> {addFeaturesList(3)} </div>
                </div>

              </section>

              <div className={styles.discountedContainer}>
                <section className={styles.pricingCard}>
                  <div className={styles.pricingContent}>
                    <h2
                      className={`${styles.pricingTitle} text-sky-600`}
                    >
                      Pro
                    </h2>
                    <div className={styles.priceContainer}>
                      <div className={styles.numberContainer}>
                        <p className={styles.dollar}>$</p>
                        <div className="overflow-hidden h-[40px] relative">
                          <div className="h-[40px]">
                            <h2 className={styles.wholeNumber}>4</h2>
                          </div>
                        </div>
                        <div className="overflow-hidden h-[40px] relative">
                          <motion.div
                            animate={{ y: isMonthly ? 0 : -40 }}
                            transition={{ duration: 0.3 }}
                          >
                            <div className="h-[40px] flex">
                              <p className={styles.dollar}>.00</p>
                              <div className="flex items-end">
                                <p className={styles.pricePlanText}>/mo</p>
                              </div>
                            </div>
                            <div className="h-[40px] flex">
                              <h2 className={styles.wholeNumber}>0</h2>
                              <p className={styles.dollar}>.00</p>
                              <div className="flex items-end">
                                <p className={styles.pricePlanText}>/yr</p>
                              </div>
                            </div>
                          </motion.div>
                        </div>
                      </div>
                    </div>
                    <Link href="" className={`${styles.buyButton} bg-sky-600 hover:bg-white text-white hover:text-sky-600`}>Buy Now</Link>
                    <div className={styles.featureListTitle}>Basic's features plus:</div>
                    <div className={`${styles.featuresList} pt-[10px]`}> {addFeaturesList(2)} </div>
                  </div>
                </section>

                <section className={styles.pricingCard}>
                  <div className={styles.pricingContent}>
                    <h2
                      className={`${styles.pricingTitle} bg-clip-text text-transparent bg-linear-to-r from-indigo-500 via-purple-500 to-pink-400 w-[90px]`}
                    >
                      Ultra
                    </h2>
                    <div className={styles.priceContainer}>
                      <div className={styles.numberContainer}>
                        <p className={styles.dollar}>$</p>
                        <div className="overflow-hidden h-[40px] relative">
                          <div className="h-[40px]">
                            <h2 className={styles.wholeNumber}>8</h2>
                          </div>
                        </div>
                        <div className="overflow-hidden h-[40px] relative">
                          <motion.div
                            animate={{ y: isMonthly ? 0 : -40 }}
                            transition={{ duration: 0.3 }}
                          >
                            <div className="h-[40px] flex">
                              <p className={styles.dollar}>.00</p>
                              <div className="flex items-end">
                                <p className={styles.pricePlanText}>/mo</p>
                              </div>
                            </div>
                            <div className="h-[40px] flex">
                              <h2 className={styles.wholeNumber}>0</h2>
                              <p className={styles.dollar}>.00</p>
                              <div className="flex items-end">
                                <p className={styles.pricePlanText}>/yr</p>
                              </div>
                            </div>
                          </motion.div>
                        </div>
                      </div>
                    </div>
                    <Link href="" className={`${styles.buyButton} bg-sky-600 hover:bg-white text-white hover:text-sky-600`}>Buy Now</Link>
                    <div className={styles.featureListTitle}>Pro's features plus:</div>
                    <div className={`${styles.featuresList} pt-[10px]`}> {addFeaturesList(1)} </div>
                  </div>
                  
                </section>

                </div>
              </section>
            </div>
      </main>


      {/* Feature Table */}
      <section className={styles.tableSection}>
        <h1 className={styles.compareTitle}>Compare Our Plans</h1>

        <table className={styles.table}>
          <tbody className={styles.tableBody}>
            <tr className={styles.tableHeader}>
              <td className={styles.columnTitle}>Feature<hr/></td>
              <td className={styles.columnTitle}>Basic<hr/></td>
              <td className={styles.columnTitle}>Pro<hr/></td>
              <td className={styles.columnTitle}>Ultra<hr/></td>
            </tr>
            {featuresList.map((feature) => {
              let oddRow = featuresList.indexOf(feature) % 2 == 1;
              return (
                <tr className={oddRow ? styles.darkRow : styles.lightRow} key={feature.name}>
                  <td className={styles.featureCell}>{feature.name}</td>
                  <td className={styles.tableCell}>
                    <img className={styles.featureImage} src={feature.access === 3 ? "/icons/circle-checkmark.svg" : "/icons/x.svg"} />
                  </td>
                  <td className={styles.tableCell}>
                    <img className={styles.featureImage} src={feature.access >= 2 ? "/icons/circle-checkmark.svg" : "/icons/x.svg"} />
                  </td>
                  <td className={styles.tableCell}>
                    <img className={styles.featureImage} src={feature.access >= 1 ? "/icons/circle-checkmark.svg" : "/icons/x.svg"} />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </section>
    </>
  );
}
