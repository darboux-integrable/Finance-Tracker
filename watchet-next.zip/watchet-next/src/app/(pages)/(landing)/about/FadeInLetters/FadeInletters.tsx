import { motion } from "motion/react";

export default function FadeInLetters( {sentence, extraDelay = 0}: any ) {
    const letters = sentence.split("");
    
    return (
        <div>
            <div className="flex">
                {letters.map((letter: any, index: any) => (
                letter === " " ? (
                    // For spaces
                    <span key={index}>&nbsp;</span>
                ) : (
                    <motion.div
                        key={index}
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{
                            opacity: { duration: 0.5, delay: extraDelay * 0.02 + index * 0.02 }, // 0.02 is delay inbetween
                            y: { duration: 0.5, delay: extraDelay * 0.02 + index * 0.02 },
                        }}>
                        {letter}
                    </motion.div>
                )
                ))}
            </div>
        </div>
    );
}