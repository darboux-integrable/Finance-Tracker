'use client';
import { motion } from "motion/react"
import styles from "./page.module.css";
import FadeInLetters from "./FadeInLetters/FadeInletters";

export default function AboutPage() {
  return (
    <>
      <figure className={styles.sceneContainer}>
        <img
          src="/images/scenicView.jpg"
          alt="Beautiful Ocean View"
          className={styles.sceneImage}
        />
        <div className={styles.sceneDarkness}/>

        <figcaption className={styles.sceneCaption}>
          <FadeInLetters sentence="Finance Management"/>
          <div className="flex justify-center">
            <FadeInLetters extraDelay={"Finance Management".length} sentence="Should Be "/>
            
            <span className={`${styles.freeing} relative`}>
              <FadeInLetters extraDelay={"Finance Management Should Be ".length + 10} sentence="Freeing"/>

              <motion.div
                  className={`${styles.underlineAppear} absolute top-0 left-0`}
                  initial={{ width: "0%",}}
                  animate={{ width: "82%",}}
                  transition={{
                      ease: "linear", 
                      width: { duration: 0.55, delay: "Finance management should be freeing".length * 0.02}
                  }}>
                  Freeing
              </motion.div>

            </span> 
          </div>
        </figcaption>
      </figure>
      


      <main className={styles.aboutUsContent}>
        <section className={styles.goalSection}>

          <div className={styles.goalHeaderContainer}>
            <div>
              <h1 className={styles.aboutUsTitle}>About Watchet</h1>
              <hr className={styles.titleAccent}/>
            </div>
          </div>

          <article className={`${styles.goalArticleGrid} md:max-w-[60vw] max-w-[90vw]`}>

            <img src="/images/theProblem.png" alt="" className={`${styles.image1} order-1`}/>
            <div className={`${styles.para1} order-2`}>
              <h2 className={styles.goalHeader}>The Problem</h2>
              <p className={styles.goalParagraph}>
                Every day, inflation keeps driving up the cost of everyday things, and wages just aren’t keeping up like they used to.
                For a lot of us, the cycle starts as early as college—student loans, high interest rates, and debts that only seem to grow.
                And while financial advisers and money management apps exist, they often take tons of research or come with expensive subscriptions.
                <sup className="text-[var(--secondary-text-color)] text-[0.8em]">Wasn't the goal to save money?</sup>
              </p>
            </div>

            <img src="/images/mission.png" alt="" className="order-4"/>
            <div className="order-3">
              <h2 className={styles.goalHeader}>Our Mission</h2>
              <p className={styles.goalParagraph}>
                As soon to be college students ourselves, we worry about student loans and needing to save with what little money we can.
                We designed Watchet to be an all-in-one finance management platform with simplicity and accessibility at the forefront.
                Our mission is to empower anyone to be able to make smarter, more connected financial decisions through a seamless and intuitive experience.
              </p>
            </div>
            

          </article>
        </section>

        <section className={`${styles.howSection} bg-blue-400 dark:bg-sky-700`}>
          <h1 className={styles.howTitle}>The Technology Used</h1>
          <section className={styles.resourcesGrid}>
            <article className={styles.resource}>
              <div className={styles.resourceHeader}>
                <h2 className={styles.resourceTitle}>Firebase</h2>
                <img
                  className={styles.resourceLogo}
                  src="/companyLogos/firebaseLogo.svg"
                  alt="firebase logo"
                />
              </div>
              <p className={styles.resourceDescription}>
                Firebase is a Backend as a Service (BaaS), owned by Google, that
                we used to securly store user information in their database. It
                also allows us to easily integrate with other Google developer services.
              </p>
            </article>
            <article className={styles.resource}>
              <div className={styles.resourceHeader}>
                <h2 className={styles.resourceTitle}>Stripe</h2>
                <img
                  className={styles.resourceLogo}
                  src="/companyLogos/stripeLogo.svg"
                  alt="stripe logo"
                />
              </div>
              <p className={styles.resourceDescription}>
                Stripe provides payment processing infrastructure; it allows Watchet
                to accept payments online and in app—whether that's from
                credit/debit cards, bank transfers, or other payment methods.
              </p>
            </article>
            <article className={styles.resource}>
              <div className={styles.resourceHeader}>
                <h2 className={styles.resourceTitle}>React</h2>
                <img
                  className={styles.resourceLogo}
                  src="/companyLogos/reactLogo.svg"
                  alt="react logo"
                />
              </div>
              <p className={styles.resourceDescription}>
                React is a frontend framework that simplifies creating the
                frontend. It allows developers to create reuseable page elements to
                reduce bloat and more easily manage reactivity.
              </p>
            </article>
            <article className={styles.resource}>
              <div className={styles.resourceHeader}>
                <h2 className={styles.resourceTitle}>React Expo</h2>
                <img
                  className={styles.resourceLogo}
                  src="/companyLogos/expoLogo.svg"
                  alt="expo logo"
                />
              </div>
              <p className={styles.resourceDescription}>
                Built on React Native, stream lines the development of a mobile app 
                by allowing for similar syntax and elements used within React. Also provides
                along with easy access to mobile features like haptics and sensors.
              </p>
            </article>
            
          </section>
        </section>

        <section className={styles.developersSection}>

          <div className={styles.howHeaderContainer}>
            <div>
              <h1 className={styles.aboutUsTitle}>The Developers</h1>
              <hr className={styles.titleAccent}/>
            </div>
          </div>

          <section className={styles.developerSection}>
            
            
            <div className="flex gap justify-center items-center">
              <div className="w-[400px]">
                <div className={styles.developerImageContainer}>
                    <div className={styles.clipPath}>
                      <img className={styles.developer} src="/images/nobgPortrait.png" alt="" />
                    </div>
                </div>
                <div className={styles.developerTextContainer}>
                  <h2 className={styles.developerName}>Tyler Robucci</h2>
                  <p className={styles.developerText}>
                      Co-CEO & Co-Founder
                  </p>
                </div>
              </div>

              <div className="w-[400px]">
                <div className={styles.developerImageContainer}>
                    <div className={styles.clipPath2}>
                      <img className={styles.developer2} src="/images/adamPortrait.png" alt="" />
                    </div>
                </div>
                <div className={styles.developerTextContainer}>
                  <h2 className={styles.developerName}>Adam Evans</h2>
                  <p className={styles.developerText}>
                      Co-CEO & Co-Founder
                  </p>
                </div>
              </div>

            </div>

            <div className={`${styles.bitAboutMeContainer} bg-[var(--lvl2-container)] w-[50%] rounded-[20px] shadow-sm p-[10px]`}>
              <h2 className={styles.developerName}>A Bit About Us:</h2>
              <p className={styles.developerText}>
                  Hey, we're Tyler and Adam, the developers of Watchet! Currently, we're still highschool students. Dedicated and competitive, we're looking to push to be one of best the within our field.
              </p>
            </div>


          </section>

        </section>
      </main>
    </>
  );
}
