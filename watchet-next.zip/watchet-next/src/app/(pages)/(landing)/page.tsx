import Chart from "../../components/landing/Chart/Chart"

import styles from "./page.module.css";

const gradient = "background: linear-gradient(45deg, oklab(89.9% -0.061 -0.046), oklab(81.7% -0.11 -0.086), oklab(85.7% -0.037 -0.068), oklab(88.8% -0.046 -0.045), oklab(66.3% 0.015 -0.179))";

// Index.js / Landing
export default function Landing() {
  return (
      <>
        <section className={`${styles.gradient} bg-sky-500 flex h-[70vh]  justify-center items-center p-[50px]`}>
          <main className="flex flex-row h-[100%] w-[70vw] rounded-[20px] justify-center items-center bg-[var(--lvl1-container)] gap-[5vw] py-[30px] px-[2.5vw]">
            <div className="flex flex-col gap-[30px] overflow-hidden min-w-max max-w-max">
              <div>
                <h1 className="text-[3vw] font-bold whitespace-nowrap text-[var(--primary-text-color)]">The All-In-One<br/>Finance Manager</h1>
                <h2 className="text-[2em] text-[var(--secondary-text-color)]">Made just for you</h2>
              </div>
              <button className="w-[150px] h-[50px] bg-sky-500 rounded-full text-white 
              hover:bg-sky-400 active:bg-sky-600 transition-all duration-200">
                Get Started
              </button>
            </div>
            <div className="flex grow w-[5vw] h-[70%] p-[10px] shadow-lg rounded-[10px] justify-center items-center bg-[var(--background)]">
                <Chart></Chart>
            </div>
          </main>
        </section>

        <div className="">
          Hello
        </div>
      </>
  );
}
