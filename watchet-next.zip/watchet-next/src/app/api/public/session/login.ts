// app/api/session/route.ts
import { cookies } from "next/headers"
import { NextResponse } from "next/server"
import { adminAuth } from "@/app/lib/firebase.admin"

export async function POST(request: Request) {
  try {
    const { token, remember } = await request.json()
    if (!token) {
      return NextResponse.json("Missing token", { status: 400 })
    }

    // 2 hours or 7 days
    const expiresIn = remember
      ? 7 * 24 * 60 * 60 * 1000 // 7 days
      : 2 * 60 * 60 * 1000 // 2 hours

    const decodedToken = await adminAuth.verifyIdToken(token)
    const nowInSeconds = Date.now() / 1000
    if (nowInSeconds - decodedToken.auth_time > 300) {
      return NextResponse.json("Recent login required", { status: 401 })
    }

    const sessionCookie = await adminAuth.createSessionCookie(token, {
      expiresIn,
    })

    const cookieStore = await cookies()
    cookieStore.set({
      name: "session",
      value: sessionCookie,
      httpOnly: true,
      secure: true,
      sameSite: "strict",
      path: "/",
      maxAge: expiresIn / 1000,
    })

    return NextResponse.json("OK", { status: 200 })
  } catch (error: any) {
    return NextResponse.json(error.code || "Internal error", { status: 500 })
  }
}