import { NextResponse } from "next/server"
import { adminAuth, firestore } from "@/app/lib/firebase.admin"
import { FieldValue } from "firebase-admin/firestore"

export async function POST(request: Request) {
  try {
    const { email, password, username } = await request.json()
    if (!email || !password || !username) {
      return NextResponse.json("Missing parameter(s)", { status: 400 })
    }

    const usernamesRef = firestore.collection("usernames")
    const userDoc = await usernamesRef.doc(username.toLowerCase()).get()

    if (userDoc.exists) {
      return NextResponse.json("Username taken", { status: 409 })
    }

    // Create user in Firebase Auth
    const userRecord = await adminAuth.createUser({ email, password })
    const uid = userRecord.uid

    // Reserve username
    await usernamesRef.doc(username.toLowerCase()).set({ uid })

    // Create user document
    const usersRef = firestore.collection("users")
    await usersRef.doc(uid).set({
      username,
      pfpURL: "",
      createdAt: FieldValue.serverTimestamp(),
      incomes: [],
      expenses: [],
      preferences: {
        darkMode: false,
      },
    })

    return NextResponse.json("OK", { status: 200 })
  } catch (error: any) {
    return NextResponse.json(error.code || "Internal error", { status: 500 })
  }
}