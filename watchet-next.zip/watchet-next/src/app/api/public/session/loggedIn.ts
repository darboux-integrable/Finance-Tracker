import { cookies } from "next/headers";
import { NextResponse } from "next/server";

export async function POST() {
  const cookieStore = await cookies();
  const cookie = cookieStore.get("session");

  if (!cookie) {
    return NextResponse.json("Unauthorized", { status: 401 });
  }

  return NextResponse.json("OK", { status: 200 });
}