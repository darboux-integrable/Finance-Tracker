import { initializeApp, getApps } from "firebase/app";

// SDKs
import { getAuth, setPersistence, inMemoryPersistence } from "firebase/auth"

const firebaseConfig = {
  apiKey: "AIzaSyDBlzEvQQH8oPqcOpd_3mTFb_GU1uVlxSI",
  authDomain: "watchet-7a0b6.firebaseapp.com",
  projectId: "watchet-7a0b6",
  storageBucket: "watchet-7a0b6.firebasestorage.app",
  messagingSenderId: "712691719371",
  appId: "1:712691719371:web:b72a181685c1e91c444f4e"
};

// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApps()[0]

// Export firebase services / modules
export const auth = getAuth(app);

async function noPersist() {
  await setPersistence(auth, inMemoryPersistence);
}
noPersist();
