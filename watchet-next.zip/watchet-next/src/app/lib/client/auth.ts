import {
  signInWithEmailAndPassword,
  sendSignInLinkToEmail,
  signInWithEmailLink,
  isSignInWithEmailLink,
  sendPasswordResetEmail,
  confirmPasswordReset,
  verifyPasswordResetCode
} from "firebase/auth";

import { auth } from "@/app/lib/client/firebase.client";

// DONE : Signup
export const signup = async(email: string, password: string, username: string) => {
  try {
    const res = await fetch("/api/session/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: email, password: password, username: username })
    });

    if(!res.ok) {
      throw await res.text();
    }

  } catch (error) {
    throw error;
  }
}

// Login : Log via backend if you want to not expose if email or password was wrong
export const login = async (email: string, password: string, rememberMe: boolean) => {
  try {
    const userCred = await signInWithEmailAndPassword(auth, email, password);
    const user = userCred.user;

    if(!user.emailVerified) {
      await auth.signOut();
      throw "Email not verified";
    }

    const idToken = await user.getIdToken();

    // Send token to Vercel API route
    const res = await fetch("/api/session/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: idToken, remember: rememberMe })
    });

    if(!res.ok) {
      throw await res.text();
    }

    // Sign out in client, manage session in backend
    await auth.signOut();

  } catch (error: any) {
    if (error.code) { // Need b/c logging in via frontend
      throw error.code;
    }
    throw error;      
  }
}

// Sign out
export const logout = async () => {
  try {
    const res = await fetch("/api/session/logout", { method: "POST" });

    if (!res.ok) {
      throw "Logout failed";
    }

  } catch (error) {
    throw error;
  }
};


// Email login (Email verification handled above)
export const emailLogin = async (email: any) => { 
  try {
    const actionCodeSettings = {
      url: window.location.origin + "/verify",
      handleCodeInApp: true,
    };

    await sendSignInLinkToEmail(auth, email, actionCodeSettings);
    window.localStorage.setItem("emailForSignIn", email);

  } catch (error) {
    throw error;
  }
}

export const completeSignIn = async () => {
  try {
    if (isSignInWithEmailLink(auth, window.location.href)) {
      let email = window.localStorage.getItem('emailForSignIn');

      const userCred = await signInWithEmailLink(auth, email!, window.location.href);

      window.localStorage.removeItem('emailForSignIn');

      const idToken = await userCred.user.getIdToken();

      // Login
      const res = await fetch("/api/session/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: idToken })
      });

      await auth.signOut();

      if (!res.ok) {
        throw await res.json();
      }
    }
  } catch (error) {
    throw error;
  }
}

// In future turn into backend request for generatePasswordResetLink for custom reset page
export const forgotPassword = async (email: string) => {
  try {
    const actionCodeSettings = {
      url: window.location.origin + "/login",
      handleCodeInApp: false
    };
    await sendPasswordResetEmail(auth, email, actionCodeSettings);
    window.localStorage.setItem("emailForSignIn", email);
  } catch (error) {
    throw error;
  }
}

// Must generate PW reset link from backend with custom SMTP server / another time
export const changePassword = async (code: any, newPassword: string) => {
  try {
    await verifyPasswordResetCode(auth, code);
    
    await confirmPasswordReset(auth, code, newPassword);
    window.localStorage.removeItem('emailForSignIn');

  } catch (error) {
    throw error;
  }
}

export const checkLogin = async () => {
  const res = await fetch("/api/session/loggedIn", { method: "POST" });

  if(!res.ok) return false;
  
  return true;
}