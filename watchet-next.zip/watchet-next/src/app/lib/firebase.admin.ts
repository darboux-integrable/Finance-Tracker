import { initializeApp, cert, getApps, getApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore } from "firebase-admin/firestore";
import { getStorage } from "firebase-admin/storage";

const app = getApps().length === 0
  ? initializeApp({
    credential: cert({
      projectId: process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
    }),
    storageBucket: "gs://watchet-7a0b6.firebasestorage.app",
  })
  : getApp();

export const firebaseAdmin = app;
export const adminAuth = getAuth(firebaseAdmin);
export const firestore = getFirestore(firebaseAdmin);
export const storage = getStorage(firebaseAdmin).bucket();

/**
 * Resolves a username to a UID.
 * @param username - the username to look up
 * @returns UID string if found, otherwise null
 */
export async function getUidFromUsername(username: string): Promise<string | null> {
  if (!username) return null;

  const normalized = username.trim().toLowerCase();

  const docRef = firestore.collection("usernames").doc(normalized);
  const snap = await docRef.get();

  if (!snap.exists) return null;

  const data = snap.data();
  if (!data?.uid) return null;

  return data.uid;
}