import type { Metadata } from "next";
import { Toaster } from 'react-hot-toast';

import "./globals.css";
import ThemeChanger from "@/app/components/ThemeChanger";

export const metadata: Metadata = {
  title: "Watchet",
  description: "All-in-one finance manager",
};

// Equivalent to App.jsx in SolidJS
export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                const d = document.documentElement;
                const stored = localStorage.theme;
                if (
                  stored === 'dark' ||
                  (!stored && window.matchMedia('(prefers-color-scheme: dark)').matches)
                ) {
                  d.classList.add('dark');
                } else {
                  d.classList.remove('dark');
                }
              })();
            `,
          }}
        />
      </head>
      <body>
        {children}
        <Toaster position="top-right" gutter={8} />
        <div className="fixed right-[5px] bottom-[5px]">
          <ThemeChanger />
        </div>
      </body>
    </html>
  )
}