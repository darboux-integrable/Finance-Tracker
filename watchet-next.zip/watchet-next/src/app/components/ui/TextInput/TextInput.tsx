"use client";

import { useState } from "react";
import Tooltip from "@/app/components/ui/Tooltip";
import styles from "./TextInput.module.css";

type InputProps = {
  getter: { value: string; alertMsg: string };
  setter: React.Dispatch<
    React.SetStateAction<{ value: string; alertMsg: string }>
  >;
  title: string;
  autoFill?: string;
  inpType?: "password" | string;
  maxLength?: number;
  buttonImage?: string;
  buttonAlt?: string;
  buttonTooltip?: string;
  buttonAction?: () => void;
};

export default function Input({
  getter,
  setter,
  title,
  autoFill = "off",
  inpType = "text",
  maxLength = 32,
  buttonImage,
  buttonAlt,
  buttonAction,
}: InputProps) {
  const [isVisible, setVisible] = useState(inpType === "password" ? false : true);

  const borderClass =
    getter.alertMsg === ""
      ? `${styles.container} border-neutral-600 border-[1px]`
      : `${styles.container} border-red-400 border-[2px]`;

  const handleButtonClick = () => {
    if (inpType === "password") {
      setVisible(!isVisible);
    } else if (buttonAction) {
      buttonAction();
    }
  };

  const getButtonImage = () => {
    if (inpType === "password") {
      return isVisible
        ? "/icons/eye-open.svg"
        : "/icons/eye-closed.svg";
    }
    return buttonImage || "";
  };

  const getButtonAlt = () => {
    if (inpType === "password") return isVisible ? "Hide password" : "Show password";
    return buttonAlt || "Button";
  };

  return (
    <div className={borderClass}>

      <label htmlFor={title} className="translate-y-[-100%] absolute flex flex-row w-full ">
        <p className={getter.alertMsg === "" ? "grow text-[var(--secondary-text-color)] font-bold " : "grow text-red-400 font-bold"}>
          {title}
        </p>

        {getter.alertMsg !== "" && getter.alertMsg !== "!" && (
        <div className="flex flex-row place-items-center">
          <img src="/icons/alert.svg" alt="!" className="w-[18px] h-[18px]" />
          <p className="text-red-400 text-[14px]">{getter.alertMsg}</p>
        </div>
        )}

      </label>

      <input
        id={title}
        type={isVisible ? "text" : "password"}
        className={styles.input}
        value={getter.value}
        onChange={(e) => setter((prev) => ({ ...prev, value: e.target.value }))}
        onClick={() => setter((prev) => ({ ...prev, alertMsg: "" }))}
        maxLength={maxLength}
        autoComplete={autoFill === "" ? "off" : autoFill}
        spellCheck={false}
        required
      />

      {/* Divider */}
      <div className={`h-[30px] w-[2px] bg-neutral-500 rounded-full my-auto mr-[2px] ${getter.alertMsg === "" ? "bg-[var(--secondary-text-color)]" : "bg-red-400"}`} />

      {/* Side Button */}
      {(inpType === "password" || buttonImage) && (
        <div className="relative inline-flex items-center justify-center">
          <Tooltip message={getButtonAlt() || ""}>
            <button
              type="button"
              className={`cursor-pointer p-[7px] mr-[5px] rounded-[15px]
                filter invert brightness-150
                dark:brightness-0
                hover:bg-[rgba(255,255,255,0.15)]
                active:bg-[rgba(255,255,255,0.1)] active:scale-95
                transition-all duration-100`}
              onClick={handleButtonClick}
            >
              <img
                className={styles.sideButtonImage}
                src={getButtonImage()}
                alt={getButtonAlt()}
              />
            </button>
          </Tooltip>
        </div>
      )}
    </div>
  );
}