"use client";

import { useState, ReactNode } from "react";
import { motion, AnimatePresence } from "framer-motion";

type PropTypes = {
  message?: string;
  position?: "top" | "bottom" | "left" | "right";
  delay?: number;
  children: ReactNode;
};

export default function Tooltip({
  message = "",
  position = "top",
  delay = 1000,
  children,
}: PropTypes) {
  const [hovered, setHovered] = useState(false);
  const delaySeconds = delay / 1000;

  const positionClass: Record<string, string> = {
    top: "bottom-full mb-2 left-1/2 -translate-x-1/2",
    bottom: "top-full mt-2 left-1/2 -translate-x-1/2",
    left: "right-full mr-2 top-1/2 -translate-y-1/2",
    right: "left-full ml-2 top-1/2 -translate-y-1/2",
  };

  const arrowPosition: Record<string, string> = {
    top: "top-full left-1/2 -translate-x-1/2 border-t-neutral-950",
    bottom: "bottom-full left-1/2 -translate-x-1/2 border-b-neutral-950",
    left: "left-full top-1/2 -translate-y-1/2 border-l-neutral-950",
    right: "right-full top-1/2 -translate-y-1/2 border-r-neutral-950",
  };

  return (
    <div
      className="relative inline-block"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <AnimatePresence>
        {hovered && (
          <motion.div
            key="tooltip"
            className={`absolute z-10 bg-neutral-950 text-white text-xs px-2 py-1 rounded whitespace-nowrap ${positionClass[position]}`}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{
              opacity: 0,
              scale: 0.9,
              transition: { duration: 0.1 }
            }}
            transition={{
              opacity: { duration: 0.2, delay: delaySeconds },
              scale: { duration: 0.2, delay: delaySeconds },
            }}
          >
            {message}
            <div
              className={`absolute w-0 h-0 border-4 border-transparent ${arrowPosition[position]}`}
            />
          </motion.div>
        )}
      </AnimatePresence>
      {children}
    </div>
  );
}