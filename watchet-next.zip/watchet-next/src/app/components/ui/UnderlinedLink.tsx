'use client';

import { motion } from "motion/react";
import Link from "next/link";
import { useState } from "react";

export default function UnderlineLink({ href="/", className="text-[1.2em] text-[var(--primary-text-color)]", children }: any) {
  const [hover, setHover] = useState(false);

  const variants = {
    hidden: { scaleX: 0, transformOrigin: "right" },
    visible: { scaleX: 1, transformOrigin: "left" },
  };

  return (
    <Link
        href={href}
        className={`relative px-1 inline-flex ${className}`}
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
    >
    {children}
    <motion.div
        style={{
            position: "absolute",
            bottom: "0px",
            left: 0,
            right: 0,
            height: "3px",
            background: "var(--color-sky-600)",
        }}
        variants={variants}
        initial="hidden"
        animate={hover ? "visible" : "hidden"} 
        transition={{ duration: 0.25 }}
    />
    </Link>
  );
}