"use client";
import { useEffect, useState } from "react";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  Colors,
  registerables,
  LineElement,
  PointElement,
  LinearScale,
  CategoryScale,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(LineElement, PointElement, LinearScale, CategoryScale, Tooltip, Legend);
ChartJS.register(...registerables);
ChartJS.register(Colors);

const months = [
  "Jan.", "Feb.", "Mar.", "Apr.", "May", "June",
  "July", "Aug.", "Sept.", "Oct.", "Nov.", "Dec."
];

export default function OpeningGraph() {
  const currentDate = new Date();
  const initialMonths = 6;
  const startMonth = currentDate.getMonth();
  const startYear = currentDate.getFullYear();

  // Initialize labels
  const initialLabels = Array.from({ length: initialMonths }, (_, i) => {
    const monthIndex = (startMonth + i) % 12;
    const year = startYear + Math.floor((startMonth + i) / 12);
    return `${months[monthIndex]} ${year}`;
  });

  // Initialize datasets with 0s
  const initialDatasets = [
  { 
    label: "Account 1", 
    data: Array.from({ length: initialMonths }, () => Math.floor(Math.random() * 100)), 
    tension: 0.3, 
  },
  { 
    label: "Account 2", 
    data: Array.from({ length: initialMonths }, () => Math.floor(Math.random() * 100)), 
    tension: 0.3, 
  },
  { 
    label: "Account 3", 
    data: Array.from({ length: initialMonths }, () => Math.floor(Math.random() * 100)), 
    tension: 0.3, 
  },
];

  const [chartData, setChartData] = useState({
    labels: initialLabels,
    datasets: initialDatasets,
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setChartData((prevData) => {
        const lastLabel = prevData.labels[prevData.labels.length - 1];
        const [monthStr, yearStr] = lastLabel.split(" ");
        let monthIndex = months.indexOf(monthStr);
        let year = parseInt(yearStr);

        // Increment month
        monthIndex++;
        if (monthIndex === 12) {
          monthIndex = 0;
          year++;
        }
        const newLabel = `${months[monthIndex]} ${year}`;

        // Update datasets with new random points
        const newDatasets = prevData.datasets.map((dataset) => {
          const last = dataset.data[dataset.data.length - 1] ?? 0;
          let next = last + Math.floor(Math.random() * 50 - 25);
          next = Math.max(0, Math.min(100, next)); // Clamp 0-100

          const newData = [...dataset.data, next];
          if (newData.length > initialMonths) newData.shift();

          return { ...dataset, data: newData };
        });

        // Update labels
        const newLabels = [...prevData.labels, newLabel];
        if (newLabels.length > initialMonths) newLabels.shift();

        return { labels: newLabels, datasets: newDatasets };
      });
    }, 1750);

    return () => clearInterval(interval);
  }, []);
  
  const options: any = {
    responsive: true,
    maintainAspectRatio: false, 
    animation: { duration: 500, easing: "easeOutElastic" },
    scales: {
      x: { ticks: { minRotation: 0, maxRotation: 0 } },
      y: {
        min: 0,
        max: 100,
        title: { display: true, text: "Current Balance ($)" },
      },
    },
  };

  return <Line data={chartData} options={options} />;
}