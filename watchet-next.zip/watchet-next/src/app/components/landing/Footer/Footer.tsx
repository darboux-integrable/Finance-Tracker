import Link from 'next/link';

const linkClass = "text-sky-500 hover:text-sky-400";
import UnderlineLink from "@/app/components/ui/UnderlinedLink";

export default function Footer() {
  return (
    <footer className="flex w-full bg-[var(--navigation)] h-[60px] px-[5vw] z-9999">
      {/* Left */}
      <div className="flex flex-1 items-center text-[var(--primary-text-color)]">
        <p>© 2025 Watchet Inc.</p>
      </div>

      {/* Center */}
      <div className="flex flex-1 justify-center items-center gap-5">
            <UnderlineLink href="/legal" className={linkClass}> Legal </UnderlineLink>
            <UnderlineLink href="/faq" className={linkClass}>FAQ</UnderlineLink>
            <UnderlineLink href="/contact" className={linkClass}>Contact</UnderlineLink>
      </div>

      {/* Right */}
      <div className="flex flex-row flex-1 justify-end place-items-center">
            <Link href="https://youtube.com/@TheTCoder">
              <img className="w-[30px] h-[30px]" src="/companyLogos/gitHubLogo.svg"alt=""/>
            </Link>
      </div>
    </footer>
  );
}