import Link from 'next/link';

import styles from "./Navbar.module.css"
import UnderlineLink from "@/app/components/ui/UnderlinedLink"
export default function Navbar() {
    return (
        <div>
            <nav className={`${styles.navigation}`}>
            
                <div className={styles.titleContainer}>
                    <Link href="/" className={styles.titleImage}>
                        <img src="/brand/titleIcon.svg" alt="Watchet"/>
                    </Link>
                </div>
                <div className={styles.linksContainer}>
                    <UnderlineLink href="/about">About</UnderlineLink>
                    <UnderlineLink href="/pricing">Pricing</UnderlineLink>
                    <UnderlineLink href="/help">Help</UnderlineLink>
                </div>
                <div className={styles.authContainer}>
                    <Link href="/login" className={styles.loginButton}>
                        Login
                    </Link>
                    <Link href="/signup" className={styles.signupButton}>
                        Sign Up
                    </Link>
                </div>
            </nav>
        </div>
    )
}