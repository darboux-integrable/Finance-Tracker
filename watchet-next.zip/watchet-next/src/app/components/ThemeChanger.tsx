'use client'; // Can use document
import { useState, useEffect } from 'react';

export default function ThemeChanger() {
    const [theme, setTheme] = useState<'light' | 'dark'>('light');
    useEffect(() => {
        const theme = localStorage.getItem('theme') || 'light';
        setTheme(theme as 'light' | 'dark');
        document.documentElement.classList.add(theme);
    }, []);

    const toggleTheme = () => {
        const next = theme === 'dark' ? 'light' : 'dark';
        document.documentElement.classList.remove(theme);
        document.documentElement.classList.add(next);
        localStorage.setItem('theme', next);
        setTheme(next);
    };

    return (
        <button 
            onClick={() => toggleTheme()}
            className = {`
                w-[30px] h-[30px] rounded-full text-[20px] 
                bg-white dark:bg-black 
                rotate-0 dark:rotate-360 
                transition-all duration-300 ease-in-out
            `}
        >
            {theme === 'light' ? "☀️" : "🌙"}
        </button>
    );
}